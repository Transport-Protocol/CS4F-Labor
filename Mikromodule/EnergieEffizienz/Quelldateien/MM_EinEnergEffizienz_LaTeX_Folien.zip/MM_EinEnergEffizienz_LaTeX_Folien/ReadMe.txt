%ReadMe.txt

Diese Folien benötigen den XeLateX  oder LuaLaTeX-Compiler.

Das Hauptdokument ist MM_EinEnergEffizienz.tex.

Die Bibliothek ist die NAHlab.bib und es muss biber genutzt werden.

